# openDog
CAD and code for each episode of my open source dog series

All CAD and code is licensed under GPL3: https://www.gnu.org/licenses/gpl-3.0.en.html
