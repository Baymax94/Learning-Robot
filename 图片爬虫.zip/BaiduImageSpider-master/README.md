# BaiduImageSpider
百度图片爬虫，基于python3

个人学习开发用

提高了爬虫的容错率、稳定性

单线程爬取百度图片结果

在`index.py`最后一行修改编辑查找关键字
图片默认保存在项目路径
运行爬虫：
``` python
python index.py
```

# 博客

[爬虫总结](http://www.jwlchina.cn/2016/02/06/python%E7%99%BE%E5%BA%A6%E5%9B%BE%E7%89%87%E7%88%AC%E8%99%AB/)

效果图：
![效果图](http://www.jwlchina.cn/uploads/python%E5%9B%BE%E7%89%87%E7%88%AC%E8%99%AB%E6%88%AA%E5%9B%BE.png)

# 捐赠

您的支持是对我的最大鼓励！
谢谢你请我吃糖
![wechatpay](https://raw.githubusercontent.com/kong36088/kong36088.github.io/master/uploads/site/wechat-pay.png)
![alipay](https://raw.githubusercontent.com/kong36088/kong36088.github.io/master/uploads/site/zhifubao.jpg)
